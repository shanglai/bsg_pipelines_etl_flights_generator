"""El pipeline de transformación completo: bronze -> silver -> gold.

  python -m transformacion.pipeline --landing landing --salida lakehouse
  python -m transformacion.pipeline --landing landing --salida lakehouse --hasta 2026-09-15
  python -m transformacion.pipeline --landing landing --salida lakehouse --metricas corrida.json

Códigos de salida (para el orquestador): 0 todo bien, 2 lote rechazado por calidad, 3 falla de esquema.
Si algo falla, NO se publica nada: silver y gold se quedan como estaban (falla cerrada).
"""
import argparse
import json
import logging
import shutil
import sys
import time
from datetime import date
from pathlib import Path

import polars as pl

from . import calidad, dedup, enriquecer, gold, leer, limpieza, scd
from ingesta.logs import configurar_logs, evento


def transformar(b, max_rechazo=0.02, tolerancia=3.0):
    """Función pura: recibe las tablas de bronze y devuelve las de silver y gold. No toca disco."""
    # Dimensiones
    tc = enriquecer.tipo_cambio_diario(b["tipo_cambio"])
    fotos = limpieza.clientes(b["clientes"])
    dim_historia = scd.reconstruir(fotos)
    dim_actual = dim_historia.filter("vigente").drop("valido_desde", "valido_hasta", "vigente", "version")

    # Pedidos: conformar -> deduplicar -> validar -> enriquecer
    conformados = limpieza.pedidos(b["pedidos_web"], b["pedidos_tienda"])
    unicos = dedup.ultima_version(conformados)
    validas, cuarentena = calidad.validar(unicos)
    calidad.revisar_umbrales(validas, cuarentena, max_rechazo, tolerancia)
    pedidos = enriquecer.con_cliente_historico(enriquecer.con_tipo_cambio(validas, tc), dim_historia)
    pedidos = pedidos.sort("origen", "pedido_id")

    return {
        "silver/tipo_cambio": tc,
        "silver/dim_cliente_historia": dim_historia,
        "silver/dim_cliente": dim_actual,
        "silver/pedidos": pedidos,
        "gold/ventas_diarias": gold.ventas_diarias(pedidos),
        "_cuarentena/pedidos": cuarentena,
        "_metricas": {"bronze_pedidos": len(conformados), "silver_pedidos": len(pedidos),
                      "cuarentena": len(cuarentena), "dedup": dedup.resumen(conformados),
                      "sin_tipo_cambio": pedidos["total_mxn"].null_count(),
                      "tc_viejo": int(pedidos["tc_viejo"].sum()),
                      "clientes_versiones": len(dim_historia), "clientes_vigentes": len(dim_actual)},
    }


def publicar(tablas, salida):
    """Escribe todo en una carpeta temporal y la intercambia al final: o se publica todo, o nada."""
    salida = Path(salida)
    tmp = salida.with_name(salida.name + ".tmp")
    shutil.rmtree(tmp, ignore_errors=True)
    for nombre, df in tablas.items():
        if nombre.startswith("_metricas"):
            continue
        ruta = tmp / f"{nombre}.parquet"
        ruta.parent.mkdir(parents=True, exist_ok=True)
        df.write_parquet(ruta)
    viejo = salida.with_name(salida.name + ".viejo")
    shutil.rmtree(viejo, ignore_errors=True)
    if salida.exists():
        salida.rename(viejo)
    tmp.rename(salida)
    shutil.rmtree(viejo, ignore_errors=True)


def correr(landing, salida, hasta=None, max_rechazo=0.02, tolerancia=3.0):
    inicio = time.perf_counter()
    b = leer.todas(landing, hasta)
    tablas = transformar(b, max_rechazo, tolerancia)
    publicar(tablas, salida)
    m = tablas["_metricas"] | {"segundos": round(time.perf_counter() - inicio, 2),
                               "huella_gold": gold.huella(tablas["gold/ventas_diarias"])}
    evento("transformacion_ok", **{k: v for k, v in m.items() if k != "dedup"})
    return m


def main(argv=None):
    p = argparse.ArgumentParser(description="Transformación bronze -> silver -> gold")
    p.add_argument("--landing", default="landing")
    p.add_argument("--salida", default="lakehouse")
    p.add_argument("--hasta", type=date.fromisoformat, default=None, help="última fecha de carga a considerar")
    p.add_argument("--max-rechazo", type=float, default=0.02)
    p.add_argument("--metricas", help="archivo JSON donde dejar las métricas de la corrida (para el orquestador)")
    a = p.parse_args(argv)
    configurar_logs()
    try:
        metricas = json.dumps(correr(a.landing, a.salida, a.hasta, a.max_rechazo), indent=2, default=str, ensure_ascii=False)
        if a.metricas:
            Path(a.metricas).write_text(metricas, encoding="utf-8")
        else:
            print(metricas)
        return 0
    except calidad.LoteRechazado as e:
        evento("lote_rechazado", nivel=logging.ERROR, motivos=e.motivos)
        print(e, file=sys.stderr)
        return 2
    except calidad.ErrorDeEsquema as e:
        evento("error_de_esquema", nivel=logging.ERROR, detalle=str(e))
        print(e, file=sys.stderr)
        return 3


if __name__ == "__main__":
    sys.exit(main())
