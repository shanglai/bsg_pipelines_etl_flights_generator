"""Enriquecimiento: agregar contexto de otras tablas sin perder ni multiplicar filas."""
import warnings

import polars as pl

from .limpieza import CLIENTE_DESCONOCIDO, fecha_negocio

DIAS_MAX_TC = 4   # si el último tipo de cambio disponible tiene más de 4 días, algo anda mal en la fuente


def tipo_cambio_diario(tc_bronze):
    """Una tasa por fecha. Si una fecha llegó en varias cargas, gana la carga más reciente (trae las correcciones)."""
    return (tc_bronze.filter((pl.col("base") == "USD") & (pl.col("moneda") == "MXN"))
            .sort("fecha_carga").unique(subset="fecha", keep="last")
            .select("fecha", pl.col("tasa").alias("mxn_por_usd")).sort("fecha"))


def con_tipo_cambio_ingenuo(pedidos, tc):
    """El join obvio... que pierde las ventas de fin de semana y días feriados."""
    return (pedidos.with_columns(fecha_negocio=fecha_negocio())
            .join(tc, left_on="fecha_negocio", right_on="fecha", how="inner"))


def con_tipo_cambio(pedidos, tc):
    """Join 'as of': para cada venta, la última tasa publicada en o antes de su fecha de negocio."""
    salida = (pedidos.with_columns(fecha_negocio=fecha_negocio()).sort("fecha_negocio")
              .join_asof(tc.with_columns(fecha_tc=pl.col("fecha")).sort("fecha"),
                         left_on="fecha_negocio", right_on="fecha", strategy="backward")
              .with_columns(dias_tc=(pl.col("fecha_negocio") - pl.col("fecha_tc")).dt.total_days()))
    return salida.with_columns(
        total_mxn=pl.when(pl.col("moneda") == "MXN").then(pl.col("total"))
                    .when(pl.col("moneda") == "USD").then((pl.col("total") * pl.col("mxn_por_usd")).round(2)),
        tc_viejo=pl.col("dias_tc") > DIAS_MAX_TC,
    )


def con_cliente_actual(pedidos, dim_actual):
    """Atributos del cliente HOY (SCD tipo 1)."""
    return (pedidos.join(dim_actual.select("cliente_id", "ciudad", "segmento"), on="cliente_id", how="left")
            .with_columns(pl.col("ciudad").fill_null("Desconocida"), pl.col("segmento").fill_null("desconocido")))


def con_cliente_historico(pedidos, dim_historia):
    """Atributos del cliente EN LA FECHA DE LA VENTA (SCD tipo 2): join por punto en el tiempo."""
    dim = dim_historia.select("cliente_id", "valido_desde", "valido_hasta", "ciudad", "segmento").sort("valido_desde")
    with warnings.catch_warnings():          # Polars avisa que no puede verificar el orden dentro de cada cliente
        warnings.simplefilter("ignore")
        salida = (pedidos.sort("fecha_negocio")
                  .join_asof(dim, left_on="fecha_negocio", right_on="valido_desde", by="cliente_id", strategy="backward"))
    vigente = pl.col("fecha_negocio") < pl.col("valido_hasta")   # la versión encontrada debe seguir viva ese día
    return salida.with_columns(
        ciudad=pl.when(vigente).then(pl.col("ciudad")).otherwise(pl.lit("Desconocida")),
        segmento=pl.when(vigente).then(pl.col("segmento")).otherwise(pl.lit("desconocido")),
    ).drop("valido_desde", "valido_hasta")


def sin_cliente(pedidos):
    """Pedidos cuyo cliente no aparece en la dimensión (sin contar las ventas de mostrador)."""
    return pedidos.filter((pl.col("ciudad") == "Desconocida") & (pl.col("cliente_id") != CLIENTE_DESCONOCIDO))
