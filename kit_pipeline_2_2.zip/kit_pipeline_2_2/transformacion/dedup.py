"""Deduplicación: quedarse con UNA fila por llave de negocio, y que sea la correcta."""
import polars as pl

LLAVE = ["origen", "pedido_id"]
# Orden de desempate: la versión más reciente en el origen; si empatan, la que se extrajo después
ORDEN = ["actualizado_en", "_extraido_en"]


def ultima_version(df, llave=LLAVE, orden=ORDEN):
    return df.sort(orden).unique(subset=llave, keep="last", maintain_order=True)


def resumen(df, llave=LLAVE):
    """¿Cuánta duplicación hay y de qué tipo?"""
    exactos = len(df) - len(df.unique())
    return {"filas": len(df), "llaves": df.select(llave).n_unique(), "duplicados_exactos": exactos,
            "versiones_de_mas": len(df) - exactos - df.select(llave).n_unique()}
