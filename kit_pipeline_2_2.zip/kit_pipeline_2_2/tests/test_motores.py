import pytest

from procesamiento import generar_historial, motores, parquet_interno


@pytest.fixture(scope="module")
def historial(tmp_path_factory):
    carpeta = tmp_path_factory.mktemp("historial")
    generar_historial.generar(carpeta, filas=60_000, n_clientes=500, n_productos=100)
    return carpeta


@pytest.mark.parametrize("funcion", sorted(set(motores.MOTORES.values()) | set(motores.FUERA_DE_MEMORIA.values())))
def test_todos_los_motores_dan_la_misma_respuesta(historial, funcion):
    referencia = motores.duckdb_parquet(historial)
    resultado = getattr(motores, funcion)(historial)
    assert len(resultado) == len(referencia) > 0
    assert (resultado["unidades"] == referencia["unidades"]).all()
    assert ((resultado["ingreso_mxn"] - referencia["ingreso_mxn"]).abs() < 0.05).all()


def test_ordenar_por_fecha_permite_saltar_row_groups(historial):
    # con 60 mil filas solo hay un row group; probamos la lógica de conteo con el archivo ordenado
    necesarios, total = parquet_interno.row_groups_necesarios(historial / "lineas_ordenado.parquet",
                                                              __import__("datetime").datetime(2025, 12, 1),
                                                              __import__("datetime").datetime(2026, 1, 1))
    assert 1 <= necesarios <= total
