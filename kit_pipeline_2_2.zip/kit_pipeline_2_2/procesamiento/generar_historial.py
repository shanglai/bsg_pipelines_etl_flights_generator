"""Historial de ventas de la tienda a escala: millones de líneas de pedido, reproducibles.

Uso local:  python -m procesamiento.generar_historial --filas 10000000 --salida datos_historial
            (con 8 GB de RAM o menos, usa --filas 3000000)
Escribe:
  lineas.csv                         un solo CSV grande (como lo entregaría un sistema legado)
  lineas.parquet                     el mismo contenido en un solo Parquet
  lineas_ordenado.parquet            ordenado por fecha (para ver el salto de row groups)
  lineas_particionado/anio=AAAA/mes=MM/*.parquet   particionado estilo Hive
  clientes.parquet, productos.parquet
"""
import argparse
import shutil
import time
from pathlib import Path

import numpy as np
import polars as pl

SEMILLA = 987654
CIUDADES = ["CDMX", "Guadalajara", "Monterrey", "Puebla", "Querétaro", "Mérida", "Lima", "Bogotá", "Santiago", "Cusco"]
CATEGORIAS = ["Electrónica", "Hogar", "Juguetes", "Ropa", "Deportes", "Belleza", "Libros", "Mascotas", "Jardín", "Cocina"]
CANALES = ["web", "app", "tienda"]


def escribir_particionado(df, destino, columnas):
    """Particionado estilo Hive: destino/anio=2025/mes=12/archivo.parquet"""
    try:
        df.write_parquet(destino, partition_by=columnas)
    except TypeError:   # Polars antiguo: lo hacemos con pyarrow
        import pyarrow.dataset as ds
        ds.write_dataset(df.to_arrow(), destino, format="parquet", partitioning=columnas, partitioning_flavor="hive")


def generar(salida, filas=10_000_000, n_clientes=50_000, n_productos=2_000, semilla=SEMILLA):
    salida = Path(salida)
    if salida.exists():
        shutil.rmtree(salida)
    salida.mkdir(parents=True)
    rng = np.random.default_rng(semilla)
    inicio = time.perf_counter()

    clientes = pl.DataFrame({
        "cliente_id": np.arange(1, n_clientes + 1, dtype=np.int64),
        "ciudad": rng.choice(CIUDADES, n_clientes, p=[.30, .14, .13, .08, .06, .05, .10, .07, .04, .03]),
        "segmento": rng.choice(["nuevo", "frecuente", "vip"], n_clientes, p=[.6, .32, .08]),
    })
    productos = pl.DataFrame({
        "producto_id": np.arange(1, n_productos + 1, dtype=np.int64),
        "categoria": rng.choice(CATEGORIAS, n_productos),
        "precio_lista": np.round(rng.lognormal(5.5, 0.9, n_productos), 2),
    })

    # Fechas en 3 años con más ventas en noviembre-diciembre (Buen Fin y fiestas)
    dias = (pl.date_range(pl.date(2023, 1, 1), pl.date(2025, 12, 31), "1d", eager=True))
    peso = np.where(dias.dt.month().to_numpy() >= 11, 2.0, 1.0)
    dia_idx = rng.choice(len(dias), filas, p=peso / peso.sum())
    segundos = rng.integers(0, 86_400, filas)
    producto = rng.integers(1, n_productos + 1, filas)
    precio_lista = productos["precio_lista"].to_numpy()[producto - 1]

    lineas = pl.DataFrame({
        "linea_id": np.arange(1, filas + 1, dtype=np.int64),
        "pedido_id": (np.arange(filas) // 3 + 1).astype(np.int64),
        "fecha": (dias.to_numpy()[dia_idx].astype("datetime64[s]") + segundos.astype("timedelta64[s]")).astype("datetime64[us]"),
        "cliente_id": rng.integers(1, n_clientes + 1, filas),
        "producto_id": producto,
        "cantidad": rng.integers(1, 6, filas).astype(np.int32),
        "precio_unitario": np.round(precio_lista * rng.uniform(0.9, 1.1, filas), 2),
        "descuento": rng.choice([0.0, 0.0, 0.0, 0.05, 0.10, 0.15], filas),
        "moneda": rng.choice(["MXN", "USD"], filas, p=[.85, .15]),
        "canal": rng.choice(CANALES, filas, p=[.5, .35, .15]),
    })

    lineas.write_csv(salida / "lineas.csv")
    lineas.write_parquet(salida / "lineas.parquet", row_group_size=500_000)
    # El mismo contenido ordenado por fecha: las estadísticas min/max de cada row group sirven para saltar datos
    lineas.sort("fecha").write_parquet(salida / "lineas_ordenado.parquet", row_group_size=500_000)
    escribir_particionado(lineas.with_columns(anio=pl.col("fecha").dt.year(), mes=pl.col("fecha").dt.month()),
                          salida / "lineas_particionado", ["anio", "mes"])
    clientes.write_parquet(salida / "clientes.parquet")
    productos.write_parquet(salida / "productos.parquet")
    return {"filas": filas, "segundos": round(time.perf_counter() - inicio, 1),
            "csv_mb": round((salida / "lineas.csv").stat().st_size / 2**20),
            "parquet_mb": round((salida / "lineas.parquet").stat().st_size / 2**20)}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Genera el historial de ventas de la tienda")
    p.add_argument("--filas", type=int, default=10_000_000)
    p.add_argument("--salida", default="datos_historial")
    a = p.parse_args()
    print(generar(a.salida, a.filas))
