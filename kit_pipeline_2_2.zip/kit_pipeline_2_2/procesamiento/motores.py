"""La misma pregunta de negocio resuelta con distintos motores de un solo nodo.

Pregunta: ingreso neto mensual (en MXN) y unidades por categoría y ciudad, solo 2025 y solo canal web.
Todas las funciones reciben la carpeta del historial y devuelven un DataFrame de pandas con el mismo
esquema y orden, para poder comprobar que todos los motores dan exactamente la misma respuesta.
"""
from pathlib import Path

import duckdb
import pandas as pd
import polars as pl

TIPO_CAMBIO_USD = 17.0
COLUMNAS = ["mes", "categoria", "ciudad", "unidades", "ingreso_mxn"]
NECESARIAS = ["fecha", "cliente_id", "producto_id", "cantidad", "precio_unitario", "descuento", "moneda", "canal"]


def _final(df):
    df = df[COLUMNAS].copy()
    df["mes"] = df["mes"].astype("int64")
    df["unidades"] = df["unidades"].astype("int64")
    df["ingreso_mxn"] = df["ingreso_mxn"].astype("float64").round(2)
    df["categoria"] = df["categoria"].astype(str)
    df["ciudad"] = df["ciudad"].astype(str)
    return df.sort_values(["mes", "categoria", "ciudad"]).reset_index(drop=True)


# ---------------- pandas ----------------
def _pandas_consulta(lineas, d):
    productos = pd.read_parquet(d / "productos.parquet")
    clientes = pd.read_parquet(d / "clientes.parquet")
    lineas = lineas[(lineas["fecha"].dt.year == 2025) & (lineas["canal"] == "web")]
    lineas = lineas.merge(productos[["producto_id", "categoria"]], on="producto_id").merge(clientes[["cliente_id", "ciudad"]], on="cliente_id")
    factor = lineas["moneda"].map({"MXN": 1.0, "USD": TIPO_CAMBIO_USD})
    lineas = lineas.assign(mes=lineas["fecha"].dt.month,
                           ingreso_mxn=lineas["cantidad"] * lineas["precio_unitario"] * (1 - lineas["descuento"]) * factor)
    r = lineas.groupby(["mes", "categoria", "ciudad"], as_index=False).agg(unidades=("cantidad", "sum"), ingreso_mxn=("ingreso_mxn", "sum"))
    return _final(r)


def pandas_csv(carpeta):
    """Lo más común en la práctica: leer el CSV completo a memoria y después filtrar."""
    d = Path(carpeta)
    return _pandas_consulta(pd.read_csv(d / "lineas.csv", parse_dates=["fecha"]), d)


def pandas_parquet(carpeta):
    """Mismo código, pero leyendo Parquet (y solo las columnas necesarias)."""
    d = Path(carpeta)
    return _pandas_consulta(pd.read_parquet(d / "lineas.parquet", columns=NECESARIAS), d)


# ---------------- Polars ----------------
def _polars_consulta(lineas, d, lazy):
    leer = pl.scan_parquet if lazy else pl.read_parquet
    productos, clientes = leer(d / "productos.parquet"), leer(d / "clientes.parquet")
    return (lineas
            .filter((pl.col("fecha").dt.year() == 2025) & (pl.col("canal") == "web"))
            .join(productos.select("producto_id", "categoria"), on="producto_id")
            .join(clientes.select("cliente_id", "ciudad"), on="cliente_id")
            .with_columns(mes=pl.col("fecha").dt.month(),
                          ingreso_mxn=pl.col("cantidad") * pl.col("precio_unitario") * (1 - pl.col("descuento"))
                          * pl.when(pl.col("moneda") == "USD").then(TIPO_CAMBIO_USD).otherwise(1.0))
            .group_by("mes", "categoria", "ciudad")
            .agg(unidades=pl.col("cantidad").sum(), ingreso_mxn=pl.col("ingreso_mxn").sum()))


def polars_eager(carpeta):
    """Polars en modo inmediato: cada paso se ejecuta al momento, como pandas, pero multihilo y sobre Arrow."""
    d = Path(carpeta)
    return _final(_polars_consulta(pl.read_parquet(d / "lineas.parquet"), d, lazy=False).to_pandas())


def plan_polars_lazy(carpeta):
    d = Path(carpeta)
    return _polars_consulta(pl.scan_parquet(d / "lineas.parquet"), d, lazy=True)


def polars_lazy(carpeta):
    """Polars en modo diferido: primero arma el plan, lo optimiza y solo entonces lee lo necesario."""
    return _final(plan_polars_lazy(carpeta).collect().to_pandas())


def _streaming(plan):
    try:
        return plan.collect(engine="streaming")
    except TypeError:   # versiones anteriores de Polars
        return plan.collect(streaming=True)


def polars_streaming_csv(carpeta):
    """Polars procesando el CSV por partes (streaming): no necesita tenerlo completo en memoria."""
    d = Path(carpeta)
    return _final(_streaming(_polars_consulta(pl.scan_csv(d / "lineas.csv", try_parse_dates=True), d, lazy=True)).to_pandas())


# ---------------- DuckDB ----------------
SQL = """
SELECT month(l.fecha) AS mes, p.categoria, c.ciudad,
       SUM(l.cantidad) AS unidades,
       SUM(l.cantidad * l.precio_unitario * (1 - l.descuento) * CASE WHEN l.moneda = 'USD' THEN {tc} ELSE 1 END) AS ingreso_mxn
FROM {lineas} l
JOIN read_parquet('{d}/productos.parquet') p USING (producto_id)
JOIN read_parquet('{d}/clientes.parquet') c USING (cliente_id)
WHERE year(l.fecha) = 2025 AND l.canal = 'web'
GROUP BY ALL ORDER BY ALL
"""


def duckdb_parquet(carpeta):
    """DuckDB consultando el Parquet directamente con SQL: sin cargarlo antes a memoria."""
    d = Path(carpeta).as_posix()
    return _final(duckdb.sql(SQL.format(tc=TIPO_CAMBIO_USD, d=d, lineas=f"read_parquet('{d}/lineas.parquet')")).df())


def duckdb_csv_limitado(carpeta, memoria="300MB"):
    """DuckDB sobre el CSV con un límite de memoria artificialmente bajo: si no le alcanza, usa disco."""
    d = Path(carpeta).as_posix()
    con = duckdb.connect()
    con.execute(f"SET memory_limit = '{memoria}'")
    con.execute(f"SET temp_directory = '{d}/_duckdb_tmp'")
    return _final(con.sql(SQL.format(tc=TIPO_CAMBIO_USD, d=d, lineas=f"read_csv('{d}/lineas.csv')")).df())


# ---------------- pandas por partes ----------------
def pandas_chunks_csv(carpeta, filas_por_parte=1_000_000):
    """pandas leyendo el CSV por partes: cada parte se filtra y se agrega, y al final se combinan los parciales."""
    d = Path(carpeta)
    productos = pd.read_parquet(d / "productos.parquet")[["producto_id", "categoria"]]
    clientes = pd.read_parquet(d / "clientes.parquet")[["cliente_id", "ciudad"]]
    parciales = []
    for parte in pd.read_csv(d / "lineas.csv", usecols=NECESARIAS, parse_dates=["fecha"], chunksize=filas_por_parte):
        parte = parte[(parte["fecha"].dt.year == 2025) & (parte["canal"] == "web")]
        parte = parte.merge(productos, on="producto_id").merge(clientes, on="cliente_id")
        factor = parte["moneda"].map({"MXN": 1.0, "USD": TIPO_CAMBIO_USD})
        parte = parte.assign(mes=parte["fecha"].dt.month,
                             ingreso_mxn=parte["cantidad"] * parte["precio_unitario"] * (1 - parte["descuento"]) * factor)
        parciales.append(parte.groupby(["mes", "categoria", "ciudad"], as_index=False)[["cantidad", "ingreso_mxn"]].sum())
    r = pd.concat(parciales).groupby(["mes", "categoria", "ciudad"], as_index=False).sum()
    return _final(r.rename(columns={"cantidad": "unidades"}))


MOTORES = {
    "pandas · CSV": "pandas_csv",
    "pandas · Parquet": "pandas_parquet",
    "Polars · inmediato": "polars_eager",
    "Polars · diferido": "polars_lazy",
    "DuckDB · Parquet": "duckdb_parquet",
}
FUERA_DE_MEMORIA = {
    "pandas · CSV completo": "pandas_csv",
    "pandas · CSV por partes": "pandas_chunks_csv",
    "Polars · streaming CSV": "polars_streaming_csv",
    "DuckDB · CSV con 300 MB": "duckdb_csv_limitado",
}


def base(carpeta):
    """No hace nada: sirve para medir la memoria que ocupan Python y las librerías por sí solas."""
    return pd.DataFrame(columns=COLUMNAS)
